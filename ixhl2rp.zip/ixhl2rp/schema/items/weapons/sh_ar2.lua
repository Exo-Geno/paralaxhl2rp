ITEM.name = "Pulse-Rifle"
ITEM.description = "A dark energy powered assault rifle."
ITEM.model = "models/weapons/w_irifle.mdl"
ITEM.class = "weapon_ar2"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 4
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}