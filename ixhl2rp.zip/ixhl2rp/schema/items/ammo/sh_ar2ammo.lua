ITEM.name = "Pulse-Rifle Energy"
ITEM.model = "models/items/combine_rifle_cartridge01.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A Cartridge that contains %s of AR2 Ammo"
ITEM.classes = {CLASS_EOW}
