
ITEM.name = "Citizen Identification Card"
ITEM.model = Model("models/sky/cid.mdl")
ITEM.description = "A citizen identification card with ID #%s, assigned to %s."
ITEM.category = "Cards"

function ITEM:GetDescription()
	return string.format(self.description, self:GetData("id", "00000"), self:GetData("name", "nobody"))
end

local red = Color(255, 0, 0)

function ITEM:PopulateTooltip(tooltip)
    local data = tooltip:AddRow("data")
    data:SetBackgroundColor(red, tooltip)
    data:SetText("This card contains an RFID chip that can be linked to the owner. If you find one of these and it is not yours, return it to U.C.A Functionaries.")
    data:SetFont("BudgetLabel")
    data:SetExpensiveShadow(0.5)
    data:SizeToContents()
end