
FACTION.name = "Union Civil Authority"
FACTION.description = "A Paramilitary police force funded and lead by the Universal union."
FACTION.color = Color(50, 100, 150)
FACTION.pay = 10
FACTION.models = {"models/conceptbine_policeforce/conceptpolice_nemez.mdl"}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true
FACTION.runSounds = {[0] = "NPC_MetroPolice.RunFootstepLeft", [1] = "NPC_MetroPolice.RunFootstepRight"}

function FACTION:OnSpawn( client )
	local id = client:FindBodygroupByName( "boots" )
	client:SetBodygroup( id, 1 )
  end

function FACTION:GetDefaultName(client)
	return "UCA.i1-CDT." .. Schema:ZeroNumber(math.random(1, 9999), 4), true
end

function FACTION:OnTransferred(character)
	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end


FACTION_MPF = FACTION.index
