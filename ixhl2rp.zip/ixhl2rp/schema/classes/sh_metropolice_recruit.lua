CLASS.name = "Union Civil Authority Cadet"
CLASS.faction = FACTION_MPF
CLASS.isDefault = true

function CLASS:CanSwitchTo(client)
	return Schema:IsCombineRank(client:Name(), "CDT")
end

CLASS_MPR = CLASS.index