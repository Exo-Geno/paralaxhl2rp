# Handcuffs
Adds handcuffs to the server, which allow you to tie up players.

## Installation
- Download the zip
- Extract it into your Schema's plugin folder

