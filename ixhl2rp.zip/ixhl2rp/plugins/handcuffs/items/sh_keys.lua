
ITEM.name = "Handcuffs Key"
ITEM.model = Model("models/props_c17/TrapPropeller_Lever.mdl")
ITEM.description = "An universal key designed to open handcuffs"
ITEM.category = "Tools"
ITEM.width = 1
ITEM.height = 1

