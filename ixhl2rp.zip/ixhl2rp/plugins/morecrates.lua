local PLUGIN = PLUGIN

PLUGIN.name = "More crates"
PLUGIN.author = "Usuariozombie"
PLUGIN.description = "You can add boxes using this code, with every single model."

-- ix.container.Register("model", {
-- 	name = "Box",
-- 	description = "Description.",
-- 	width = 4,
-- 	height = 4,
-- })