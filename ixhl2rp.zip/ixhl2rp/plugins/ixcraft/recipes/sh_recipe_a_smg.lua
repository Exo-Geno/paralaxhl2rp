
RECIPE.name = "SMG Ammo"
RECIPE.description = "Craft a SMG ammunition."
RECIPE.model = "models/Items/BoxSRounds.mdl"
RECIPE.category = "Ammunition"
RECIPE.requirements = {
	["comp_refined_metal"] = 3,
		["comp_gunpowder"] = 4,
	["comp_metal"] = 4
}
RECIPE.results = {
	["smg1ammo"] = 1
}



RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_workbench")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a workbench."
end)
