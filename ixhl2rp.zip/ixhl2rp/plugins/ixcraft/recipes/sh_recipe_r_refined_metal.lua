
RECIPE.name = "Refined Metal"
RECIPE.description = "Refine the scrap metal"
RECIPE.model = "models/gibs/scanner_gib02.mdl"
RECIPE.category = "Refining"
RECIPE.requirements = {
	["comp_metal"] = 2,
	["comp_wood"] = 1
}
RECIPE.results = {
	["comp_refined_metal"] = {["min"] = 1, ["max"] = 2},

}

RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_furnace")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a furnace."
end)
