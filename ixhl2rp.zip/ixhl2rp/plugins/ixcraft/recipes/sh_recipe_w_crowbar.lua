
RECIPE.name = "Crowbar"
RECIPE.description = "Craft a crowbar."
RECIPE.model = "models/weapons/w_crowbar.mdl"
RECIPE.category = "Weapons"
RECIPE.requirements = {
	["comp_refined_metal"] = 4,
	["comp_metal"] = 2,
	["comp_cloth"] = 2
}
RECIPE.results = {
	["crowbar"] = 1
}



RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_workbench")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a workbench."
end)
