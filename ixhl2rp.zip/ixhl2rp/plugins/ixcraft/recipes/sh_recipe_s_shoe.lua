
RECIPE.name = "Scrap the shoe"
RECIPE.description = "Scrap the old shoe to get some cloth out of it"
RECIPE.model = "models/props_junk/shoe001a.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_shoe"] = 1
}
RECIPE.results = {
	["comp_cloth"] = 1

}

