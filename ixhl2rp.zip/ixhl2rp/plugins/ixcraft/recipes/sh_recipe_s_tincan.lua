
RECIPE.name = "Scrap the tin can"
RECIPE.description = "Scrap the can to get some metal out of it"
RECIPE.model = "models/props_junk/garbage_metalcan002a.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_tincan"] = 1
}
RECIPE.results = {
	["comp_metal"] = {["min"] = 1, ["max"] = 2},

}

