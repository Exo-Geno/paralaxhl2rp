
RECIPE.name = "Scrap the gear"
RECIPE.description = "Scrap the old, gear to get some metal out of it"
RECIPE.model = "models/props_wasteland/gear02.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_gear"] = 1
}
RECIPE.results = {
	["comp_metal"] = 2

}

