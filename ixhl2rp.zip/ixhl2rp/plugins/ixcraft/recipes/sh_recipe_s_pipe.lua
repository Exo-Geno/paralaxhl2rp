
RECIPE.name = "Scrap the pipe"
RECIPE.description = "Scrap the flimsy pipe to get some metal out of it"
RECIPE.model = "models/props_canal/mattpipe.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_pipe"] = 1
}
RECIPE.results = {
	["comp_metal"] = 1

}

