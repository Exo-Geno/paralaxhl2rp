
RECIPE.name = "MP5K"
RECIPE.description = "Craft an MP5K."
RECIPE.model = "models/weapons/tfa_ins2/w_mp5k.mdl"
RECIPE.category = "Weapons"
RECIPE.requirements = {
	["comp_refined_metal"] = 13,
	["comp_metal"] = 6
}
RECIPE.results = {
	["smg2"] = 1
}



RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_workbench")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a workbench."
end)
