
RECIPE.name = "Scrap the wooden toy"
RECIPE.description = "Scrap the toy to get some wood out of it"
RECIPE.model = "models/props_c17/playgroundtick-tack-toe_block01a.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_toy"] = 1
}
RECIPE.results = {
	["comp_wood"] = {["min"] = 1, ["max"] = 2},

}

