
RECIPE.name = "Wooden Handle Knife"
RECIPE.description = "Craft a singular knife."
RECIPE.model = "models/yurie/eft/weapons/world/bars_a-2607_95x18.mdl"
RECIPE.category = "Weapons"
RECIPE.requirements = {
	["comp_wood"] = 15,
	["comp_cloth"] = 5
}
RECIPE.results = {
	["knife3"] = 1
}



RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_workbench")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a workbench."
end)
