
RECIPE.name = "Shotgun Ammo"
RECIPE.description = "Craft a Shotgun ammunition."
RECIPE.model = "models/Items/BoxBuckshot.mdl"
RECIPE.category = "Ammunition"
RECIPE.requirements = {
	["comp_refined_metal"] = 2,
		["comp_gunpowder"] = 6,
	["comp_metal"] = 6
}
RECIPE.results = {
	["shotgunammo"] = 1
}



RECIPE:PostHook("OnCanCraft", function(recipeTable, client)
	for _, v in pairs(ents.FindByClass("ix_station_workbench")) do
		if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
			return true
		end
	end

	return false, "You need to be near a workbench."
end)
