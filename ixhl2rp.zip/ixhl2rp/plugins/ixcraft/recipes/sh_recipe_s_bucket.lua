
RECIPE.name = "Scrap the bucket"
RECIPE.description = "Scrap the bucket to get some metal out of it"
RECIPE.model = "models/props_junk/metalbucket01a.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_toy"] = 1
}
RECIPE.results = {
	["comp_metal"] = 1

}

