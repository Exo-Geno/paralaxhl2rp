
RECIPE.name = "Scrap the drawer"
RECIPE.description = "Scrap the old, tattered drawer to get some wood out of it"
RECIPE.model = "models/props_c17/FurnitureDrawer001a_Chunk01.mdl"
RECIPE.category = "Scrap"
RECIPE.requirements = {
	["junk_tattered_drawer"] = 1
}
RECIPE.results = {
	["comp_wood"] = 2

}

