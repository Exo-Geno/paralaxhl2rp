
STATION.name = "Furnace"
STATION.description = "Old, working furnace for refining the metals"
STATION.model = "models/props/cs_militia/furnace01.mdl"
