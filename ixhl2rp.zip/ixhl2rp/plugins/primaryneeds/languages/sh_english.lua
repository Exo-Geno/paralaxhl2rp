
LANGUAGE = {

	hunger = "Hunger",
	hungerDied = "You starved to death",
	
	hungerHealthy = "Satiated",
	hungerSnack = "A bit hungry",
	hungerHungry = "Hungry",
	hungerStarving = "Very hungry",
	hungerDeath = "Starving to Death",
	
	thirst = "Thirst",
	thirstDied = "You died from dehydration",
	
	thirstHealthy = "Hydrated",
	thirstBit = "A bit thirsty",
	thirstThirsty = "Thirsty",
	thirstDehydrated = "Very thirsty",
	thirstDeath = "Dehydrated",
	
	setHunger = "%s adjusted %s 's hunger to %s",
	setThirst = "%s adjusted %s 's thirst to %s",
}
