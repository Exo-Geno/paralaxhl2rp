
LANGUAGE = {

	hunger = "Hambre",
	hungerDied = "Has muerto de hambre",
	
	hungerHealthy = "Saciado",
	hungerSnack = "Algo Hambriento",
	hungerHungry = "Hambriento",
	hungerStarving = "Muy Hambriento",
	hungerDeath = "Muriendo de Hambre",
	
	thirst = "Sed",
	thirstDied = "Has muerto de sed",
	
	thirstHealthy = "Hidratado",
	thirstBit = "Algo Sediento",
	thirstThirsty = "Sediento",
	thirstDehydrated = "Muy Sediento",
	thirstDeath = "Deshidratado",
	
	setHunger = "%s ha ajustado el hambre de %s a %s",
	setThirst = "%s ha ajustado la sed de %s a %s",
}
