ITEM.name = "Breen's Private Reserve Special Water"
ITEM.description = "A yellow, soda-like can with special water inside. Something is off about it..."
ITEM.model = Model("models/willardnetworks/food/breencan2.mdl")
ITEM.category = "UU-Branded Items"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 15, 0, 100))
	end
}