ITEM.name = "Radio-Bob Drink"
ITEM.description = "A Royal purple, soda-like can with a carbonated drink."
ITEM.model = Model("models/willardnetworks/food/bobdrinks_can.mdl")
ITEM.category = "UU-Branded Items"
ITEM.skin = 0
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 13 , 0, 100))
	end
}