ITEM.name = "Breen's Private Reserve Water"
ITEM.description = "A Blue, soda-like can with water inside. Something is off about it..."
ITEM.model = Model("models/props_junk/PopCan01a.mdl")
ITEM.category = "UU-Branded Items"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 12, 0, 100))
	end
}