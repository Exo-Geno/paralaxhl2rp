ITEM.name = "Drink Example"
ITEM.description = "An example item."
ITEM.model = Model("models/props_junk/PopCan01a.mdl")
ITEM.class = "Example"
ITEM.category = "Consumables"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 50, 0, 100))
	end
}
