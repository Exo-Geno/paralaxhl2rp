ITEM.name = "Breen's Private Reserve Sparkling Water"
ITEM.description = "A red, soda-like can with sparkling water inside. Something is off about it..."
ITEM.model = Model("models/willardnetworks/food/breencan1.mdl")
ITEM.category = "UU-Branded Items"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 12, 0, 100))
	end
}