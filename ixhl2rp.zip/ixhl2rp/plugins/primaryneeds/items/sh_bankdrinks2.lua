ITEM.name = "Bank Soda Lite"
ITEM.description = "A pink soda-like can with a carbonated drink."
ITEM.model = Model("models/willardnetworks/food/bobdrinks_goodfella.mdl")
ITEM.category = "UU-Branded Items"
ITEM.skin = 1
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 18 , 0, 100))
	end
}