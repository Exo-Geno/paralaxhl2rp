ITEM.name = "Bank Soda City 8"
ITEM.description = "A Black soda-like can with a carbonated drink. Praised be City Eight!"
ITEM.model = Model("models/willardnetworks/food/bobdrinks_goodfella.mdl")
ITEM.category = "UU-Branded Items"
ITEM.skin = 4
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5

ITEM.functions.Drink = {
	sound = "npc/barnacle/barnacle_gulp2.wav",
	OnRun = function(itemTable)
		local client = itemTable.player
		
		client:GetCharacter():SetThirst(math.Clamp(client:GetCharacter():GetThirst() + 20 , 0, 100))
	end
}