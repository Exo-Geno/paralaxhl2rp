# Primary Needs
Adds primary needs (hunger and thirst) to the characters in the server. Currently supports english and spanish languages.

## Installation
- Download the zip
- Extract it into your Schema's plugin folder
