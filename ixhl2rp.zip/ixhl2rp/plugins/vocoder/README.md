# Vocoder

Adds vocoder sounds for Overwatch soldiers. You'll want to add the workshop addon for this plugin to your server's workshop collection.

https://steamcommunity.com/sharedfiles/filedetails/?id=2291046370

https://wiki.facepunch.com/gmod/Workshop_for_Dedicated_Servers