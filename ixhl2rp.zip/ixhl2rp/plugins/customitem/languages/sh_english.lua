
LANGUAGE = {
	cmdCreateCustomItem = "Create a custom item."
}
