# Drugs
Adds a drug system to the server.

## Installation
- Download the zip
- Extract it into your Schema's plugin folder

