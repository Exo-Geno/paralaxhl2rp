PLUGIN.name = "Apply"
PLUGIN.author = "FatherSquirrel"
PLUGIN.description = "Adds the functionality to say ur name and CID or just ur name."

ix.util.Include("sh_commands.lua")