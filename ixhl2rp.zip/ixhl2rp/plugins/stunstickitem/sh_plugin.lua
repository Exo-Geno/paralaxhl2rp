PLUGIN.name = "Stunstick item"
PLUGIN.author = "LegendSMEfire aka XIII"
PLUGIN.description = "Add the Stunstick as an item."
