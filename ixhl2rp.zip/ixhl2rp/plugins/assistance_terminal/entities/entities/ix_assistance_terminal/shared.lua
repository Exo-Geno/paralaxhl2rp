
ENT.Type = "anim"
ENT.Author = "VictorK"
ENT.Category = "HL2 RP"
ENT.PrintName = "Assistance Terminal"
ENT.AdminSpawnable = true
ENT.Spawnable = true
