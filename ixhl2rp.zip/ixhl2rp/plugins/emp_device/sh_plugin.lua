PLUGIN.name = "EMP Device"
PLUGIN.author = "-Spac3"
PLUGIN.description = "Contains EMP device for hacking"
