
# HL2 RP Schema
A Half-Life 2 Roleplay schema for [Helix](https://github.com/nebulouscloud/helix).
