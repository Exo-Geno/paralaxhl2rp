ATTRIBUTE.name = "Endurance"
ATTRIBUTE.description = "Affects how long you can run for."