ATTRIBUTE.name = "Strength"
ATTRIBUTE.description = "A measure of how strong you are."